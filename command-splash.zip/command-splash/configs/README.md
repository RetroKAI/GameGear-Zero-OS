# es_runcommand_splash
Splash screens for RetroPie runcommand screen.
